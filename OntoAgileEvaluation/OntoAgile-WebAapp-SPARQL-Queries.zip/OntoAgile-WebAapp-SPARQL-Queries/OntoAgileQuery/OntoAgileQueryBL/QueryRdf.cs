﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VDS.RDF.Query;
using VDS.RDF.Parsing;
using VDS.RDF;
using VDS.RDF.Query.Datasets;
using System.Web;
using System.Data;

namespace OntoAgileQueryBL
{
    public class QueryRdf
    {
        private string rdfPath;
        public QueryRdf(string path)
        {
            rdfPath = path;
        }


        public DataSet getMethods()
        {
            
            SparqlResultSet rs = executeQuery("SELECT ?x WHERE  { ?x rdf:type ontoagile:AgileMethod. MINUS { ?x owl:sameAs ?y }}");

            DataSet ds = new DataSet();
            ds.Tables.Add(new DataTable());
            ds.Tables[0].Columns.Add("method-uri", typeof(string));
            ds.Tables[0].Columns.Add("method-name", typeof(string));


            foreach (SparqlResult result in rs)
            {
                DataRow dr = ds.Tables[0].NewRow();
                dr["method-uri"] = result["x"];
                dr["method-name"] = result["x"].ToString().Split('#')[1];

                ds.Tables[0].Rows.Add(dr);

            }
            return ds;
        }

        public DataSet getMethodValues(string methodName)
        {
            SparqlResultSet rs = executeQuery("SELECT ?z WHERE { ontoind:" + methodName + " ontoprop:hasMethodValue ?z . MINUS { ?z owl:sameAs ?y }}");

            DataSet ds = new DataSet();
            ds.Tables.Add(new DataTable());
            ds.Tables[0].Columns.Add("value-name", typeof(string));
            

            foreach (SparqlResult result in rs)
            {
                DataRow dr = ds.Tables[0].NewRow();
                dr["value-name"] = result["z"].ToString().Split('#')[1];
                ds.Tables[0].Rows.Add(dr);

            }
            return ds;
        }

        public DataSet getMethodPrinciples(string methodName)
        {
            SparqlResultSet rs = executeQuery("SELECT ?z WHERE { ontoind:" + methodName + " ontoprop:hasMethodPrinciple ?z . MINUS { ?z owl:sameAs ?y }}");

            DataSet ds = new DataSet();
            ds.Tables.Add(new DataTable());
            ds.Tables[0].Columns.Add("principle-name", typeof(string));


            foreach (SparqlResult result in rs)
            {
                DataRow dr = ds.Tables[0].NewRow();
                dr["principle-name"] = result["z"].ToString().Split('#')[1];
                ds.Tables[0].Rows.Add(dr);

            }
            return ds;
        }


        public DataSet getPhases()
        {
            
            SparqlResultSet rs = executeQuery("SELECT ?x WHERE { ?x rdf:type ontoagile:Phase}");

            DataSet ds = new DataSet();
            ds.Tables.Add(new DataTable());
            ds.Tables[0].Columns.Add("phase", typeof(string));
                        
            foreach (SparqlResult result in rs)
           {
                DataRow dr = ds.Tables[0].NewRow();
                dr["phase"] = result.ToString();
                ds.Tables[0].Rows.Add(dr);
                                
           }
            return ds;
        }

        public DataSet getValues()
        {

            SparqlResultSet rs = executeQuery2("SELECT ?x WHERE {?i rdf:type OntoAgile:Agile_value. ?i OntoAgile:hasValueDescription ?x }");
            
            DataSet ds = new DataSet();
            ds.Tables.Add(new DataTable());
            ds.Tables[0].Columns.Add("value", typeof(string));

            foreach (SparqlResult result in rs)
            {
                DataRow dr = ds.Tables[0].NewRow();
                dr["value"] = result["x"].ToString().Split('^')[0];
                ds.Tables[0].Rows.Add(dr);

            }
            return ds;
        }

        private SparqlResultSet executeQuery(string query)
        {
            IGraph g = new Graph();
            g.LoadFromFile( rdfPath);

            ISparqlDataset ds = new InMemoryDataset(g);
            LeviathanQueryProcessor processor = new LeviathanQueryProcessor(ds);
            SparqlQueryParser parser = new SparqlQueryParser();
                       
            SparqlParameterizedString queryString = new SparqlParameterizedString();
            queryString.Namespaces.AddNamespace("rdf", new Uri("http://www.w3.org/1999/02/22-rdf-syntax-ns#"));
            queryString.Namespaces.AddNamespace("owl", new Uri("http://www.w3.org/2002/07/owl#"));
            queryString.Namespaces.AddNamespace("ontoagile", new Uri("http://localhost/default#"));
            queryString.Namespaces.AddNamespace("ontoprop", new Uri("http://www.agileontologies.com/ontologies/ontoagile#"));
            queryString.Namespaces.AddNamespace("ontoind", new Uri("http://www.co-ode.org/ontologies/ont.owl#"));

            queryString.CommandText = query;
            
            SparqlQuery q = parser.ParseFromString(queryString);
            Object results = processor.ProcessQuery(q);

            return (SparqlResultSet)results;
            
        }

        private SparqlResultSet executeQuery2(string query)
        {
            IGraph g = new Graph();
            g.LoadFromFile(rdfPath);

            ISparqlDataset ds = new InMemoryDataset(g);
            LeviathanQueryProcessor processor = new LeviathanQueryProcessor(ds);
            SparqlQueryParser parser = new SparqlQueryParser();

            SparqlParameterizedString queryString = new SparqlParameterizedString();
            queryString.Namespaces.AddNamespace("rdf", new Uri("http://www.w3.org/1999/02/22-rdf-syntax-ns#"));
            queryString.Namespaces.AddNamespace("owl", new Uri("http://www.w3.org/2002/07/owl#"));
            queryString.Namespaces.AddNamespace("rdfs", new Uri("http://www.w3.org/2000/01/rdf-schema#"));
            queryString.Namespaces.AddNamespace("xsd", new Uri("http://www.w3.org/2001/XMLSchema#"));

            queryString.Namespaces.AddNamespace("OntoAgile", new Uri("http://www.semanticweb.org/ontologies/OntoAgile#"));
            
            queryString.CommandText = query;

            SparqlQuery q = parser.ParseFromString(queryString);
            Object results = processor.ProcessQuery(q);

            return (SparqlResultSet)results;

        }


    }
}
