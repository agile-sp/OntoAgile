﻿using System.Web.UI;

namespace WebAppOntoAgile.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}