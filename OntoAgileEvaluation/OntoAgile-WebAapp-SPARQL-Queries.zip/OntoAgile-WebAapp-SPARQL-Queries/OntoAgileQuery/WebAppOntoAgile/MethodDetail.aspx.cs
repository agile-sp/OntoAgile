﻿using OntoAgileQueryBL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebAppOntoAgile
{
    public partial class MethodDetail : System.Web.UI.Page
    {
        string prefInd = System.Configuration.ConfigurationManager.AppSettings["prefix-indi"];
        string path = System.Configuration.ConfigurationManager.AppSettings["owl-path"];

        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                string uri =  Request.QueryString["id"];
                lblMethod.Text = uri;
                loadMethodValues();
                loadMethodPrinciples();
            }
        }

        private void loadMethodValues()
        {
            QueryRdf q = new QueryRdf(Server.MapPath(path));
            DataSet ds = q.getMethodValues(lblMethod.Text);

            dtlValues.DataSource = ds;
            dtlValues.DataBind();

        }

        private void loadMethodPrinciples()
        {
            QueryRdf q = new QueryRdf(Server.MapPath(path));
            DataSet ds = q.getMethodPrinciples(lblMethod.Text);

            dtlPrinciples.DataSource = ds;
            dtlPrinciples.DataBind();

        }



    }
}