﻿using OntoAgileQueryBL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebAppOntoAgile
{
    public partial class _Default : Page
    {
       
        string path = System.Configuration.ConfigurationManager.AppSettings["owl-path"];

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                QueryRdf q = new QueryRdf(Server.MapPath(path));
                DataSet ds = q.getValues();

                DataList1.DataSource = ds;
                DataList1.DataBind();

            }

        }
               
    }
}